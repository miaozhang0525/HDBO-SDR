% Author: Zi Wang
function ret = WalkRobot(hyp,scale)
% Wrapper of walker_main.
% hyperparams(1) \in [1,10]
% hyperparams(2:25) \in [-2,2]
% set the first parameter to 1 if gui on
hyp=(hyp+scale)./(2*scale);

hyperparams(1)=hyp(1)*(10-1)+1;
hyperparams(2:25)=hyp(2:25)*4-2;
 
if hyperparams(1)<1
    hyperparams(1)=1;
elseif hyperparams(1)>10
    hyperparams(1)=10;
end

for i=2:25
    if hyperparams(i)<-2
        hyperparams(i)=-2;
    elseif hyperparams(i)>2
        hyperparams(i)=2;
    end
end

try
ret = NaN;
cnt = 0;
while isnan(ret) && cnt < 2
ret = walker_main(0,hyperparams(1),'demo',reshape(hyperparams(2:end), [3,8]));
close all;
cnt = cnt+1;
end
if isnan(ret)
    ret = 0;
end

catch MI
    allerror = [];
    if exist('error.mat','file') == 2
        load('error.mat');
    end
    allerror = [allerror; hyperparams];
    save('error.mat','allerror','MI')
    ret = 0;
end
