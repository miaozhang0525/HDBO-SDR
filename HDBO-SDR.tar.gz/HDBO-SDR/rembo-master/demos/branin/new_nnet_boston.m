% Copyright (c) 2017 Zi Wang
function f= new_nnet_boston(dx,scale)
% The goal is to maximize the output f. (f = 20 - validation error)
% nnsize \in [1 100] 
% mu \in [0.000001, 100]
% mu_dec \in [0.01, 1]
% mu_inc \in [1.01, 20]


dx=(dx+scale)./(2*scale);

nnsize=dx(1)*99+1;
mu=dx(2)*(100-0.000001)+0.000001;
mu_dec=dx(3)*(1-0.01)+0.01;
mu_inc=dx(4)*(20-1.01)+1.01;


    
if nnsize<1
    nnsize=1;
elseif nnsize>100
    nnsize=100;
end

if mu<0.000001
    mu=0.000001;
elseif mu>100
    mu=100;
end

if mu_dec<0.01
    mu_dec=0.01;
elseif mu_dec>1
    mu_dec=1;
end


if mu_inc<1.01
    mu_inc=1.01;
elseif mu_inc>20
    mu_inc=20;
end

s = RandStream('mcg16807','Seed', 1024);
RandStream.setGlobalStream(s);

load boston_data.mat
nnsize = floor(nnsize);
net = feedforwardnet(nnsize);
net.trainParam.max_fail = 10;
net.trainParam.min_grad = 10^(-15);
net.trainParam.mu = mu;
net.trainParam.mu_dec = mu_dec;
net.trainParam.mu_inc = mu_inc;
net.divideFcn = 'divideint';
net.divideParam.trainRatio = 0.8;
net.divideParam.valRatio = 0.1;
net.divideParam.testRatio = 0.1;
net.trainParam.time = 120;
[net,tr] = train(net,x,t);
y = net(x);
f2 = perform(net,y,t);
f = 20-tr.best_vperf; 