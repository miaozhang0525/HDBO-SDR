function startup()
clear path
cd src/;
addpath(genpath(pwd()));
cd ../

cd demos/;
addpath(genpath(pwd()));
cd ../


cd WGCCM_three_link_walker_example/;
addpath(genpath(pwd()));
cd ../