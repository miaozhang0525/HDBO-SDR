%function testAckley(varargin)
clear;
warning off;
total_iter = 50;
high_dim = 20000;
dim = 3;


Kcluster=5;
init_size=5;
%% Random embedding with true intrisic dimensions
%  True maximum is ensured to fall in to the bounds
store_data=[];
num_expe=20;
for ne=1:num_expe

    model = rembo(total_iter-init_size, dim, high_dim,init_size,Kcluster);
    fvalue=model.f;
    store_data=[store_data,fvalue];
    clear model
end
save KISIR-20000-30-WalkRobot.mat store_data



%% Run rembo.
function model = rembo(iter, dim, high_dim,init_size,Kcluster)
    % total_iter: total number of iterations.
    % dim: embedding dimension.
    % high_dim: ambient dimension.

   %     A = randn(high_dim, dim);           
 %       A = eye(high_dim, dim);

%        scale = max(1.5*log(dim), 1);
    bounds = stardardBounds(high_dim);                 % Initialize bounds.
    obj_fct = @(x) WalkRobot(x);     % Initialize the objective function.

    init_py = rand(init_size, high_dim).*2-1;     % Initial point.
    init_py(:,1)=(init_py(:,1)+1)./2.*(10-1)+1;
    

    for i=1:size(init_py,1)
        init_f(i,1) = obj_fct(init_py(i,:));  
    end% Evaluate initial point.

    hyp = [ones(dim, 1)*0.1 ; 1];          % Setup initial hyper-parameters.
    hyp = log(hyp);
    % Initialize model.
    [A,model] = init_model(high_dim,dim, bounds, init_py,init_f, hyp, 1e-5, 'ard',Kcluster);  
    % Do optimization.
    model = sparse_opt(obj_fct, iter, model,A,init_size,high_dim,Kcluster);
end
