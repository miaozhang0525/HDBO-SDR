function model = sparse_opt(objective_func, num_iter, model,A,init_size)

dopt.maxevals = 500;
dopt.maxits = 200;
dopt.showits = 0;
for i = 1:num_iter
    final_x = maximize_acq(model,A, dopt, 'ucb');
    f_t = objective_func(final_x');
    [A,model] = update_model(model, f_t, final_x',A,init_size);   
end

end