function x_max = maximize_acq(model, A,dopt, type) 
options = [];
if nargin < 4
	type = 'ucb';
end

if nargin < 5
	si = 1;
end

problem.f = @(x) acq(model, x',A, type);

cur_min = inf;
x_max = unifrnd(model.copts.LBounds, model.copts.UBounds);

if model.use_CMAES
	starting = unifrnd(model.copts.LBounds, model.copts.UBounds);
	[x_max_CMAES, fmin_CMAES, counteval, stopflag, out, bestever] =...
		cmaes(problem.f, starting, ...
		(model.copts.UBounds-model.copts.LBounds)*0.5, model.copts);

	if fmin_CMAES < cur_min
		x_max = x_max_CMAES;
		cur_min = fmin_CMAES;
	end
end
